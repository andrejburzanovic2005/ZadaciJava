class Vozilo {

    private String proizvodjac;
    private int godinaProizvodnje;
    private int kubikaza;
    private String boja;

    public Vozilo(String proizvodjac, int godinaProizvodnje, int kubikaza, String boja) {

        this.proizvodjac = proizvodjac;
        this.godinaProizvodnje = godinaProizvodnje;
        this.kubikaza = kubikaza;
        this.boja = boja;

    }

    public double cijenaRegistracije() {
        double cijena = 100; 
        if (godinaProizvodnje < 2010) {
            cijena += 30;
        }
        if (kubikaza > 2000) {
            cijena += 50;
        }
        return cijena;

    }

    public void ispisiPodatke() {
        System.out.println("Proizvođač: " + proizvodjac);
        System.out.println("Godina proizvodnje: " + godinaProizvodnje);
        System.out.println("Kubikaža: " + kubikaza);
        System.out.println("Boja: " + boja);

    }

}
class Automobil extends Vozilo {
    private int brojVrata;
    private String tipMotora;

    public Automobil(String proizvodjac, int godinaProizvodnje, int kubikaza, String boja, int brojVrata, String tipMotora) {

        super(proizvodjac, godinaProizvodnje, kubikaza, boja);
        this.brojVrata = brojVrata;
        this.tipMotora = tipMotora;

    }

    public double cijenaRegistracije() {
        double cijena = super.cijenaRegistracije();
        cijena += 20; 
        return cijena;

    }

    public void ispisiPodatke() {
        super.ispisiPodatke();
        System.out.println("Broj vrata: " + brojVrata);
        System.out.println("Tip motora: " + tipMotora);
        System.out.println("Ukupna cijena registracije: " + cijenaRegistracije() + " EUR");
    }

}

class Kamion extends Vozilo {
    private double kapacitetTereta;
    private boolean imaPrikolicu;

    public Kamion(String proizvodjac, int godinaProizvodnje, int kubikaza, String boja, double kapacitetTereta, boolean imaPrikolicu) {
        super(proizvodjac, godinaProizvodnje, kubikaza, boja);
        this.kapacitetTereta = kapacitetTereta;
        this.imaPrikolicu = imaPrikolicu;

    }

    public double cijenaRegistracije() {

        double cijena = super.cijenaRegistracije();
        if (imaPrikolicu) {
            cijena += 50; 
        }

        return cijena;

    }
    public void ispisiPodatke() {
        super.ispisiPodatke();
        System.out.println("Kapacitet tereta: " + kapacitetTereta + " t");
        System.out.println("Ima prikolicu: " + (imaPrikolicu ? "Da" : "Ne"));
        System.out.println("Ukupna cijena registracije: " + cijenaRegistracije() + " EUR");

    }

}

class Kombi extends Vozilo {
    private int kapacitetPutnika;
    public Kombi(String proizvodjac, int godinaProizvodnje, int kubikaza, String boja, int kapacitetPutnika) {
        super(proizvodjac, godinaProizvodnje, kubikaza, boja);
        this.kapacitetPutnika = kapacitetPutnika;

    }

    public double cijenaRegistracije() {

        double cijena = super.cijenaRegistracije();
        if (kapacitetPutnika > 8) {
            cijena += 30;
        }

        return cijena;

    }

    public void ispisiPodatke() {

        super.ispisiPodatke();
        System.out.println("Kapacitet putnika: " + kapacitetPutnika);
        System.out.println("Ukupna cijena registracije: " + cijenaRegistracije() + " EUR");
   
    }

}

public class Main {

    public static void main(String[] args) {

        Automobil auto = new Automobil("Audi", 2015, 1800, "Crna", 5, "Benzin");
        Kamion kamion = new Kamion("MAN", 2008, 5000, "Bijela", 12.5, true);
        Kombi kombi = new Kombi("Volkswagen", 2012, 2200, "Siva", 9);

        auto.ispisiPodatke();
        kamion.ispisiPodatke();
        kombi.ispisiPodatke();

    }

}
